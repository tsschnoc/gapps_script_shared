<!DOCTYPE HTML>
 <html>
   <head>
     <title> Hallo-Welt-Beispiel </title>
   </head>
   <body>
     <?php
       echo 'Hallo Welt!';
     ?>
   </body>
 </html>